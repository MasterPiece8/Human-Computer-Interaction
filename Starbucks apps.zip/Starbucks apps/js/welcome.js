document.getElementById('getStartedBtn').onclick = function() {
    // Redirect ke login page
    window.location.href = "login.html";
}
