 document.getElementById('goRegister').onclick = function(e) {
      e.preventDefault();
      window.location.href = "register.html";
}
document.getElementById('loginBtn').onclick = function() {
      window.location.href = "home.html";
}