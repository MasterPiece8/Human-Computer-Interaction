// Simpan dan tampilkan pickup store dari localStorage
window.addEventListener('DOMContentLoaded', () => {
  const savedStore = localStorage.getItem('pickupStore');
  if (savedStore) {
    document.getElementById('pickupStoreName').textContent = savedStore;
    document.getElementById('pickupStoreBar').style.display = 'flex';
  }
});

// Navigasi tab order (dummy, tambahkan fitur jika ingin)
function selectTab(el) {
  document.querySelectorAll('.order-tab').forEach(tab => tab.classList.remove('active'));
  el.classList.add('active');
  // Buat fungsi load data sesuai tab jika perlu
}

function goto(page) {
  window.location.href = page;
}

document.querySelectorAll('.menu-item').forEach(item => {
  item.addEventListener('click', function() {
    const menuName = this.getAttribute('data-menu');
    // Redirect ke order-detail.html dengan parameter menu
    window.location.href = `order-detail.html?menu=${encodeURIComponent(menuName)}`;
  });
});
