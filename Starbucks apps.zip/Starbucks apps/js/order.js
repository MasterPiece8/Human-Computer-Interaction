// Daftar outlet (dummy data, bisa di-load dari API/backend)
const outlets = [
  {
    id: 1,
    name: 'STARBUCKS EMPORIUM PLUIT',
    address: 'Ground Floor Unit #G-51-52, Kawasan CBD Pluit Blok, Jakarta',
    distance: '2,8 Km',
    pickup: true,
    delivery: true,
    dinein: false,
    logo: 'https://1000logos.net/wp-content/uploads/2017/08/Starbucks-Logo.png',
    hours: '09:00 – 22:00'
  },
  {
    id: 2,
    name: 'STARBUCKS JUANDA JAKARTA',
    address: 'Jl. Ir. H. Juanda III No. 1, Jakarta',
    distance: '3,8 Km',
    pickup: true,
    delivery: false,
    dinein: true,
    logo: 'https://1000logos.net/wp-content/uploads/2017/08/Starbucks-Logo.png',
    hours: '07:00 – 22:00'
  },
  // Tambahkan outlet lain sesuai kebutuhan
];

// Render outlet list
function renderOutlets(list) {
  const listDiv = document.querySelector('.outlet-list');
  listDiv.innerHTML = '';
  list.forEach(outlet => {
    let badges = '';
    if (outlet.pickup) badges += `<span class="badge pickup">Pickup</span>`;
    if (outlet.delivery) badges += `<span class="badge delivery">Delivery</span>`;
    if (outlet.dinein) badges += `<span class="badge dinein">Dine In</span>`;

    const card = `
      <div class="outlet-card">
        <div class="outlet-info">
          <div class="outlet-distance">${outlet.distance}</div>
          <div class="outlet-name">${outlet.name}</div>
          <div class="outlet-address">${outlet.address}</div>
          <div class="outlet-badges">${badges}</div>
          <div class="outlet-hours">
            <span class="hours-label">Jam Operasional:</span>
            <span class="hours-value">${outlet.hours}</span>
          </div>
        </div>
        <button class="confirm-btn" onclick="goToOrder('${outlet.name.replace(/'/g, "\\'")}')">Pilih</button>
      </div>
    `;
    listDiv.innerHTML += card;
  });
}



// Filter logic
function filterOutlets(type, search = '') {
  let filtered = outlets.filter(o => {
    // filter by type
    if (type === 'pickup') return o.pickup;
    if (type === 'delivery') return o.delivery;
    if (type === 'dinein') return o.dinein;
    return true;
  });
  // filter by search keyword
  if (search) {
    const s = search.toLowerCase();
    filtered = filtered.filter(o =>
      o.name.toLowerCase().includes(s) ||
      o.address.toLowerCase().includes(s)
    );
  }
  renderOutlets(filtered);
}

// Handle filter button click
document.querySelectorAll('.filter-btn').forEach(btn => {
  btn.addEventListener('click', function() {
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    this.classList.add('active');
    const type = this.textContent.trim().toLowerCase().replace(' ', '');
    filterOutlets(type, document.querySelector('.search-bar').value);
  });
});

// Handle search
document.querySelector('.search-bar').addEventListener('input', function() {
  const activeType = document.querySelector('.filter-btn.active').textContent.trim().toLowerCase().replace(' ', '');
  filterOutlets(activeType, this.value);
});

// Handle outlet select (simulasi redirect)
window.selectOutlet = function(id) {
  // Misal redirect ke halaman order detail
  // window.location.href = `order-detail.html?outlet=${id}`;
  alert('Outlet dipilih: ' + id);
}

// Inisialisasi (tampilkan semua outlet)
renderOutlets(outlets);

function goToOrder(outletName) {
  window.location.href = `order2.html?outlet=${encodeURIComponent(outletName)}`;
}
