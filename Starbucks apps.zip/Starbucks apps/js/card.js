// Tab Switching
document.querySelectorAll('.card-tabs .tab').forEach(tab => {
  tab.onclick = function() {
    // Set active tab
    document.querySelectorAll('.card-tabs .tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');

    // Show/hide tab-content
    const tabName = tab.getAttribute('data-tab');
    document.querySelectorAll('.tab-content').forEach(tc => tc.style.display = 'none');
    document.getElementById(tabName + 'TabContent').style.display = 'block';
  };
});

// Toggle PIN visibility
function togglePinVisibility() {
  const pinInput = document.getElementById('pinInput');
  if (pinInput.type === 'password') {
    pinInput.type = 'text';
  } else {
    pinInput.type = 'password';
  }
}

// Select Card Logic
function selectCard(event, imgSrc, number) {
  // Ganti gambar utama
  document.getElementById('mainCardImg').src = imgSrc;

  // Hilangkan semua .selected
  document.querySelectorAll('.mycard-thumb-wrap').forEach(el => el.classList.remove('selected'));
  // Kasih class selected ke yang diklik
  event.currentTarget.classList.add('selected');
}


// Card data
const cards = [
  {
    img: '../Asset/starbuckscard.jpg',
    number: '6164',
    short: '6164',
    balance: 'Rp. 9.999.999.999',
    asOf: '08/06/2025 11:57'
  },
  {
    img: '../Asset/starbuckscard2.png',
    number: '9928',
    short: '9928',
    balance: 'Rp. 150,000',
    asOf: '08/06/2025 12:31'
  }
];

let currentCardIdx = 0;

// Pilih Kartu
function selectCard(event, idx) {
  currentCardIdx = idx;
  document.getElementById('mainCardImg').src = cards[idx].img;
  document.getElementById('mainCardBalance').innerHTML = `${cards[idx].balance} <span class="refresh">&#8635;</span>`;
  document.getElementById('mainCardAsOf').innerText = `As of ${cards[idx].asOf}`;
  document.querySelectorAll('.mycard-thumb-wrap').forEach(el => el.classList.remove('selected'));
  event.currentTarget.classList.add('selected');
}

// Modal
function openModal(modalId) {
  const card = cards[currentCardIdx];

  if(modalId === 'manageCardModal') {
    document.getElementById('manageCardImg').src = card.img;
    document.getElementById('manageCardNumber').innerText = card.number;
    document.getElementById('manageBalance').innerText = card.balance;
    document.getElementById('manageAsOf').innerText = card.asOf;
  }
  if(modalId === 'payCardModal') {
    document.getElementById('payCardImg').src = card.img;
    document.getElementById('payCardShort').innerText = card.short;
    document.getElementById('payCardBalance').innerText = card.balance;
    document.getElementById('payCardAsOf').innerText = card.asOf;
  }
  document.getElementById(modalId).style.display = 'flex';
}
function closeModal(modalId) {
  document.getElementById(modalId).style.display = 'none';
}
document.querySelectorAll('.modal-bg').forEach(bg => {
  bg.onclick = function(e) {
    if(e.target === bg) bg.style.display = 'none';
  }
});

// Tab
function showTab(tab) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(tc => tc.style.display = 'none');
  if(tab === 'pay') {
    document.querySelector('.tab[data-tab="pay"]').classList.add('active');
    document.getElementById('payTabContent').style.display = 'block';
  } else if(tab === 'add') {
    document.querySelector('.tab[data-tab="add"]').classList.add('active');
    document.getElementById('addTabContent').style.display = 'block';
  } else if(tab === 'va') {
    document.querySelector('.tab[data-tab="va"]').classList.add('active');
    document.getElementById('vaTabContent').style.display = 'block';
  }
}

// Toggle Pin Visibility
function togglePinVisibility() {
  const pinInput = document.getElementById('pinInput');
  pinInput.type = (pinInput.type === "password" ? "text" : "password");
}

// Init on load
window.onload = function() {
  showTab('pay');
  selectCard({currentTarget: document.querySelector('.mycard-thumb-wrap.selected')}, 0);
}

