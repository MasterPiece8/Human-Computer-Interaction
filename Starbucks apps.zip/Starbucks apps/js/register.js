document.getElementById('goLogin').onclick = function(e) {
      e.preventDefault();
      window.location.href = "login.html";
}

document.getElementById('signupBtn').onclick = function(e) {
      e.preventDefault();
      window.location.href = "login.html";
}

document.getElementById('registerForm').addEventListener('submit', function(e) {
  e.preventDefault();

  // ambil nilai input
  const phone = document.getElementById('phone');
  const password = document.getElementById('password');
  const confirmPassword = document.getElementById('confirmPassword');
  let valid = true;

  // validasi phone
  if (phone.value.trim().length < 13) {
    phone.classList.add('input-invalid');
    document.getElementById('phoneError').textContent = "Phone number minimum 13 digits";
    valid = false;
  } else {
    phone.classList.remove('input-invalid');
    document.getElementById('phoneError').textContent = "";
  }

  // validasi password & confirm
  if (password.value !== confirmPassword.value) {
    confirmPassword.classList.add('input-invalid');
    document.getElementById('passError').textContent = "Check again";
    valid = false;
  } else {
    confirmPassword.classList.remove('input-invalid');
    document.getElementById('passError').textContent = "";
  }

  // jika semua valid, submit (misal lanjut ke proses lain)
  if (valid) {
    alert("Register berhasil! (contoh)");
    // window.location.href = 'login.html';
  }
});
