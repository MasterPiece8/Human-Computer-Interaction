// Optionally, highlight active progress node
function setActiveProgress(star) {
  const milestones = [30, 60, 120, 240, 400];
  const nodes = document.querySelectorAll('.progress-node');
  nodes.forEach((node, i) => {
    if (star >= milestones[i]) {
      node.classList.add('active');
    } else {
      node.classList.remove('active');
    }
  });
}
// setActiveProgress(0); // Bisa dipanggil untuk update tampilan

// home.js / promo slider
const wrapper = document.getElementById('promoWrapper');
const dotsContainer = document.getElementById('promoDots');
const slides = document.querySelectorAll('.promo-slide');
let current = 0;
let timer;

function showSlide(idx) {
  wrapper.style.transform = `translateX(-${idx * 134}vw)`;
  document.querySelectorAll('.promo-dot').forEach((dot, i) => {
    dot.classList.toggle('active', i === idx);
  });
}


function nextSlide() {
  current = (current + 1) % slides.length;
  showSlide(current);
}

function goToSlide(idx) {
  current = idx;
  showSlide(current);
  clearInterval(timer);
  timer = setInterval(nextSlide, 3000);
}

// Dot navigation
dotsContainer.innerHTML = '';
for (let i = 0; i < slides.length; i++) {
  const dot = document.createElement('div');
  dot.className = 'promo-dot' + (i === 0 ? ' active' : '');
  dot.onclick = () => goToSlide(i);
  dotsContainer.appendChild(dot);
}

showSlide(0);
timer = setInterval(nextSlide, 3000);

// Optional: See All action
function seeAllPromo() {
  // Misal redirect ke halaman promo
  window.location.href = 'promotion.html';
}

// Contoh data berita, kamu bisa ambil dari API atau ubah sendiri
const newsData = [
  {
    image: "https://images.unsplash.com/photo-1464983953574-0892a716854b?auto=format&fit=facearea&w=80&h=80",
    headline: "Tanggapan Starbucks mengenai konflik ...",
    title: "TRUTH MATTERS",
    desc: "Meskipun akar kami berada di Amerika Serikat, kami adalah perusahaan global d..."
  },
  {
    image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=facearea&w=80&h=80",
    headline: "Starbucks Indonesia – donasi bersama ...",
    title: "Donasi untuk Gaza",
    desc: "Starbucks Indonesia – donasi bersama untuk bantuan kemanusiaan di Gaza"
  },
  {
    image: "https://images.unsplash.com/photo-1454023492550-5696f8ff10e1?auto=format&fit=facearea&w=80&h=80",
    headline: "Get the best of Starbucks Rewards right...",
    title: "Starbucks Features",
    desc: "Did you know the Starbucks App features?"
  }
];

function openPayModal() {
  document.getElementById('payCardModal').style.display = 'flex';
}

function closeModal(id) {
  document.getElementById(id).style.display = 'none';
}


// Render news ke dalam news-list
function renderNews(news) {
  const newsList = document.getElementById("news-list");
  newsList.innerHTML = ""; // Bersihkan dulu

  news.forEach(item => {
    const newsCard = document.createElement("div");
    newsCard.className = "news-card";

    newsCard.innerHTML = `
      <img src="${item.image}" alt="${item.title}">
      <div class="news-content">
          <div class="news-headline">${item.headline}</div>
          <div class="news-title">${item.title}</div>
          <div class="news-desc">${item.desc}</div>
      </div>
    `;

    newsList.appendChild(newsCard);
  });
}

// Event button "See All News"
document.getElementById("seeAllBtn").onclick = function() {
  alert("Show all news (bisa redirect ke halaman news detail)");
};

// Inisialisasi pertama
renderNews(newsData);
