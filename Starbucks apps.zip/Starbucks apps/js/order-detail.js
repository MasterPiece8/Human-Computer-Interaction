// Counter logic
const qtySpan = document.getElementById('qty');
let qty = 1;
document.getElementById('decrease').onclick = () => {
  if (qty > 1) { qty--; qtySpan.textContent = qty; }
};
document.getElementById('increase').onclick = () => {
  qty++; qtySpan.textContent = qty;
};
